<script>
    export let name
    export let children
</script>